import {
  users,
  categories,
  suppliers,
  products,
  sales,
  saleItems,
  purchases,
  purchaseItems,
  activityLogs,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Supplier,
  type InsertSupplier,
  type Product,
  type InsertProduct,
  type ProductWithRelations,
  type Sale,
  type InsertSale,
  type SaleItem,
  type InsertSaleItem,
  type SaleWithItems,
  type Purchase,
  type InsertPurchase,
  type PurchaseItem,
  type ActivityLog,
  type InsertActivityLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, like, and, or, sql, lt } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Supplier operations
  getSuppliers(): Promise<Supplier[]>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined>;
  deleteSupplier(id: string): Promise<boolean>;

  // Product operations
  getProducts(filters?: {
    search?: string;
    categoryId?: string;
    supplierId?: string;
    lowStock?: boolean;
  }): Promise<ProductWithRelations[]>;
  getProduct(id: string): Promise<ProductWithRelations | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  updateProductStock(id: string, quantity: number): Promise<Product | undefined>;
  getLowStockProducts(): Promise<ProductWithRelations[]>;

  // Sales operations
  getSales(limit?: number): Promise<SaleWithItems[]>;
  getSale(id: string): Promise<SaleWithItems | undefined>;
  createSale(sale: InsertSale, items: InsertSaleItem[]): Promise<Sale>;
  generateInvoiceNumber(): Promise<string>;

  // Purchase operations
  getPurchases(limit?: number): Promise<Purchase[]>;
  createPurchase(purchase: InsertPurchase, items: Omit<PurchaseItem, "id">[]): Promise<Purchase>;

  // Statistics
  getDashboardStats(): Promise<{
    totalProducts: number;
    lowStockItems: number;
    totalValue: number;
    todaySales: number;
  }>;

  // Activity logs
  getRecentActivity(limit?: number): Promise<ActivityLog[]>;
  logActivity(activity: InsertActivityLog): Promise<ActivityLog>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.name));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return updated;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount > 0;
  }

  // Supplier operations
  async getSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).orderBy(asc(suppliers.name));
  }

  async createSupplier(supplier: InsertSupplier): Promise<Supplier> {
    const [newSupplier] = await db.insert(suppliers).values(supplier).returning();
    return newSupplier;
  }

  async updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const [updated] = await db
      .update(suppliers)
      .set(supplier)
      .where(eq(suppliers.id, id))
      .returning();
    return updated;
  }

  async deleteSupplier(id: string): Promise<boolean> {
    const result = await db.delete(suppliers).where(eq(suppliers.id, id));
    return result.rowCount > 0;
  }

  // Product operations
  async getProducts(filters?: {
    search?: string;
    categoryId?: string;
    supplierId?: string;
    lowStock?: boolean;
  }): Promise<ProductWithRelations[]> {
    let query = db
      .select({
        id: products.id,
        name: products.name,
        sku: products.sku,
        description: products.description,
        categoryId: products.categoryId,
        supplierId: products.supplierId,
        purchasePrice: products.purchasePrice,
        sellingPrice: products.sellingPrice,
        quantity: products.quantity,
        minStock: products.minStock,
        unit: products.unit,
        isActive: products.isActive,
        createdAt: products.createdAt,
        updatedAt: products.updatedAt,
        category: categories,
        supplier: suppliers,
      })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(suppliers, eq(products.supplierId, suppliers.id))
      .where(eq(products.isActive, true));

    const conditions = [];

    if (filters?.search) {
      conditions.push(
        or(
          like(products.name, `%${filters.search}%`),
          like(products.sku, `%${filters.search}%`)
        )
      );
    }

    if (filters?.categoryId) {
      conditions.push(eq(products.categoryId, filters.categoryId));
    }

    if (filters?.supplierId) {
      conditions.push(eq(products.supplierId, filters.supplierId));
    }

    if (filters?.lowStock) {
      conditions.push(sql`${products.quantity} <= ${products.minStock}`);
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const result = await query.orderBy(asc(products.name));
    
    return result.map(row => ({
      ...row,
      category: row.category || null,
      supplier: row.supplier || null,
    }));
  }

  async getProduct(id: string): Promise<ProductWithRelations | undefined> {
    const [result] = await db
      .select({
        id: products.id,
        name: products.name,
        sku: products.sku,
        description: products.description,
        categoryId: products.categoryId,
        supplierId: products.supplierId,
        purchasePrice: products.purchasePrice,
        sellingPrice: products.sellingPrice,
        quantity: products.quantity,
        minStock: products.minStock,
        unit: products.unit,
        isActive: products.isActive,
        createdAt: products.createdAt,
        updatedAt: products.updatedAt,
        category: categories,
        supplier: suppliers,
      })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(suppliers, eq(products.supplierId, suppliers.id))
      .where(eq(products.id, id));

    if (!result) return undefined;

    return {
      ...result,
      category: result.category || null,
      supplier: result.supplier || null,
    };
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const [updated] = await db
      .update(products)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return !!updated;
  }

  async updateProductStock(id: string, quantity: number): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set({ quantity, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return updated;
  }

  async getLowStockProducts(): Promise<ProductWithRelations[]> {
    return this.getProducts({ lowStock: true });
  }

  // Sales operations
  async getSales(limit = 50): Promise<SaleWithItems[]> {
    const salesData = await db
      .select()
      .from(sales)
      .orderBy(desc(sales.createdAt))
      .limit(limit);

    const salesWithItems: SaleWithItems[] = [];

    for (const sale of salesData) {
      const items = await db
        .select({
          id: saleItems.id,
          saleId: saleItems.saleId,
          productId: saleItems.productId,
          quantity: saleItems.quantity,
          unitPrice: saleItems.unitPrice,
          totalPrice: saleItems.totalPrice,
          product: products,
        })
        .from(saleItems)
        .innerJoin(products, eq(saleItems.productId, products.id))
        .where(eq(saleItems.saleId, sale.id));

      salesWithItems.push({
        ...sale,
        items,
      });
    }

    return salesWithItems;
  }

  async getSale(id: string): Promise<SaleWithItems | undefined> {
    const [sale] = await db.select().from(sales).where(eq(sales.id, id));
    
    if (!sale) return undefined;

    const items = await db
      .select({
        id: saleItems.id,
        saleId: saleItems.saleId,
        productId: saleItems.productId,
        quantity: saleItems.quantity,
        unitPrice: saleItems.unitPrice,
        totalPrice: saleItems.totalPrice,
        product: products,
      })
      .from(saleItems)
      .innerJoin(products, eq(saleItems.productId, products.id))
      .where(eq(saleItems.saleId, sale.id));

    return {
      ...sale,
      items,
    };
  }

  async createSale(sale: InsertSale, items: InsertSaleItem[]): Promise<Sale> {
    return await db.transaction(async (tx) => {
      // Create the sale
      const [newSale] = await tx.insert(sales).values(sale).returning();

      // Create sale items and update product stock
      for (const item of items) {
        // Insert sale item
        await tx.insert(saleItems).values({
          ...item,
          saleId: newSale.id,
        });

        // Update product stock
        await tx
          .update(products)
          .set({
            quantity: sql`${products.quantity} - ${item.quantity}`,
            updatedAt: new Date(),
          })
          .where(eq(products.id, item.productId));
      }

      return newSale;
    });
  }

  async generateInvoiceNumber(): Promise<string> {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    
    const prefix = `INV-${year}${month}-`;
    
    const [lastSale] = await db
      .select({ invoiceNumber: sales.invoiceNumber })
      .from(sales)
      .where(like(sales.invoiceNumber, `${prefix}%`))
      .orderBy(desc(sales.invoiceNumber))
      .limit(1);

    let nextNumber = 1;
    if (lastSale) {
      const lastNumber = parseInt(lastSale.invoiceNumber.replace(prefix, ''));
      nextNumber = lastNumber + 1;
    }

    return `${prefix}${String(nextNumber).padStart(4, '0')}`;
  }

  // Purchase operations
  async getPurchases(limit = 50): Promise<Purchase[]> {
    return await db
      .select()
      .from(purchases)
      .orderBy(desc(purchases.createdAt))
      .limit(limit);
  }

  async createPurchase(purchase: InsertPurchase, items: Omit<PurchaseItem, "id">[]): Promise<Purchase> {
    return await db.transaction(async (tx) => {
      // Create the purchase
      const [newPurchase] = await tx.insert(purchases).values(purchase).returning();

      // Create purchase items and update product stock
      for (const item of items) {
        // Insert purchase item
        await tx.insert(purchaseItems).values({
          ...item,
          purchaseId: newPurchase.id,
        });

        // Update product stock
        await tx
          .update(products)
          .set({
            quantity: sql`${products.quantity} + ${item.quantity}`,
            updatedAt: new Date(),
          })
          .where(eq(products.id, item.productId));
      }

      return newPurchase;
    });
  }

  // Statistics
  async getDashboardStats(): Promise<{
    totalProducts: number;
    lowStockItems: number;
    totalValue: number;
    todaySales: number;
  }> {
    // Total products
    const [{ count: totalProducts }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(products)
      .where(eq(products.isActive, true));

    // Low stock items
    const [{ count: lowStockItems }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(products)
      .where(
        and(
          eq(products.isActive, true),
          sql`${products.quantity} <= ${products.minStock}`
        )
      );

    // Total inventory value
    const [{ value: totalValue }] = await db
      .select({
        value: sql<number>`COALESCE(SUM(${products.quantity} * ${products.purchasePrice}), 0)`,
      })
      .from(products)
      .where(eq(products.isActive, true));

    // Today's sales
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [{ total: todaySales }] = await db
      .select({
        total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
      })
      .from(sales)
      .where(
        and(
          sql`${sales.createdAt} >= ${today}`,
          sql`${sales.createdAt} < ${tomorrow}`
        )
      );

    return {
      totalProducts,
      lowStockItems,
      totalValue: Number(totalValue),
      todaySales: Number(todaySales),
    };
  }

  // Activity logs
  async getRecentActivity(limit = 20): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  async logActivity(activity: InsertActivityLog): Promise<ActivityLog> {
    const [newActivity] = await db.insert(activityLogs).values(activity).returning();
    return newActivity;
  }
}

export const storage = new DatabaseStorage();
