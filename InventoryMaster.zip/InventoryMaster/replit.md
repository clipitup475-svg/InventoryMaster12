# StockFlow - Inventory Management System

## Overview

StockFlow is a full-stack inventory management system built with React, Express, and PostgreSQL. The application provides comprehensive inventory tracking, sales management, and reporting capabilities for businesses. It features a modern web interface built with React and shadcn/ui components, a REST API backend with Express, and uses Drizzle ORM for database operations. The system includes Replit authentication for secure user access and provides real-time inventory tracking, sales processing, low stock alerts, and detailed reporting.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built with React and TypeScript, using Vite as the build tool. The UI is implemented with shadcn/ui components built on top of Radix UI primitives and styled with Tailwind CSS. State management is handled through TanStack Query for server state and React hooks for local state. The routing is implemented with Wouter for client-side navigation. The application follows a component-based architecture with separate pages for dashboard, products, sales, and reports.

### Backend Architecture
The server uses Express.js with TypeScript in ESM module format. It implements a RESTful API architecture with route handlers organized in a centralized routes file. The server includes middleware for request logging, error handling, and authentication. Database operations are abstracted through a storage layer that provides a clean interface for data access operations. The server supports both development and production modes with appropriate middleware configuration.

### Database Design
The system uses PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. The schema includes tables for users, categories, suppliers, products, sales, purchases, and activity logs with proper relationships defined. Session data is stored in the database for Replit authentication. The database configuration supports connection pooling through Neon serverless for scalability.

### Authentication System
Authentication is implemented using Replit's OpenID Connect (OIDC) authentication system with Passport.js. User sessions are managed with express-session and stored in PostgreSQL using connect-pg-simple. The system includes middleware for protecting API routes and managing user authentication state. Role-based access control is implemented with admin and staff user roles.

### State Management
Client-side state management uses TanStack Query for server state caching and synchronization. React Hook Form with Zod validation handles form state management. Local component state is managed with React hooks. The query client is configured with custom error handling and request functions.

## External Dependencies

### Database Services
- **Neon Database**: PostgreSQL hosting service used for data persistence
- **Drizzle Kit**: Database migration and schema management tools

### Authentication Services  
- **Replit Authentication**: OIDC-based authentication service integrated with Replit platform
- **OpenID Connect**: Authentication protocol implementation

### UI Component Libraries
- **Radix UI**: Headless UI component primitives for accessibility
- **shadcn/ui**: Pre-built component system based on Radix UI
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for UI elements

### Development Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking for JavaScript
- **ESLint/Prettier**: Code linting and formatting (implied from modern setup)
- **PostCSS**: CSS processing and optimization

### Utility Libraries
- **TanStack Query**: Data fetching and caching library
- **React Hook Form**: Form state management and validation
- **Zod**: Schema validation library
- **date-fns**: Date manipulation utilities
- **clsx/tailwind-merge**: Conditional CSS class utilities