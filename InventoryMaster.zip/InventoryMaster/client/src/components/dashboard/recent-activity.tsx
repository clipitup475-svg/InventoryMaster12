import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { ActivityLog } from "@shared/schema";

export default function RecentActivity() {
  const { data: activities = [], isLoading } = useQuery<ActivityLog[]>({
    queryKey: ["/api/dashboard/activity"],
    retry: false,
  });

  const getActivityIcon = (action: string) => {
    switch (action) {
      case "product_created":
      case "product_added":
        return { icon: "fas fa-plus", bgColor: "bg-green-100", iconColor: "text-green-600" };
      case "sale_completed":
        return { icon: "fas fa-shopping-cart", bgColor: "bg-blue-100", iconColor: "text-blue-600" };
      case "product_updated":
        return { icon: "fas fa-edit", bgColor: "bg-orange-100", iconColor: "text-orange-600" };
      case "product_deleted":
        return { icon: "fas fa-trash", bgColor: "bg-red-100", iconColor: "text-red-600" };
      case "category_created":
        return { icon: "fas fa-tag", bgColor: "bg-purple-100", iconColor: "text-purple-600" };
      case "supplier_created":
        return { icon: "fas fa-truck", bgColor: "bg-indigo-100", iconColor: "text-indigo-600" };
      default:
        return { icon: "fas fa-info-circle", bgColor: "bg-gray-100", iconColor: "text-gray-600" };
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} days ago`;
    
    return date.toLocaleDateString();
  };

  return (
    <Card data-testid="card-recent-activity">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Activity</CardTitle>
          <Button variant="ghost" size="sm" data-testid="button-view-all-activity">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-muted rounded-full"></div>
                    <div className="flex-1 space-y-1">
                      <div className="h-4 bg-muted rounded w-3/4"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : activities.length === 0 ? (
            <div className="text-center py-8">
              <i className="fas fa-history text-4xl text-muted-foreground mb-2"></i>
              <p className="text-muted-foreground">No recent activity</p>
              <p className="text-sm text-muted-foreground">Activity will appear here as you use the system</p>
            </div>
          ) : (
            activities.slice(0, 6).map((activity) => {
              const iconConfig = getActivityIcon(activity.action);
              return (
                <div 
                  key={activity.id} 
                  className="flex items-start space-x-3"
                  data-testid={`activity-item-${activity.id}`}
                >
                  <div className={`w-8 h-8 ${iconConfig.bgColor} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <i className={`${iconConfig.icon} ${iconConfig.iconColor} text-sm`}></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatTimeAgo(activity.createdAt?.toString() || "")}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
