import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { ProductWithRelations } from "@shared/schema";

export default function LowStockAlert() {
  const { data: lowStockProducts = [], isLoading } = useQuery<ProductWithRelations[]>({
    queryKey: ["/api/dashboard/low-stock"],
    retry: false,
  });

  return (
    <Card data-testid="card-low-stock-alerts">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Low Stock Alerts</CardTitle>
          <Button variant="ghost" size="sm" data-testid="button-view-all-low-stock">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-muted-foreground/20 rounded-lg"></div>
                      <div className="space-y-1">
                        <div className="h-4 bg-muted-foreground/20 rounded w-32"></div>
                        <div className="h-3 bg-muted-foreground/20 rounded w-20"></div>
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      <div className="h-4 bg-muted-foreground/20 rounded w-16"></div>
                      <div className="h-3 bg-muted-foreground/20 rounded w-12"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : lowStockProducts.length === 0 ? (
            <div className="text-center py-8">
              <i className="fas fa-check-circle text-4xl text-green-600 mb-2"></i>
              <p className="text-muted-foreground">All products are well stocked!</p>
              <p className="text-sm text-muted-foreground">No low stock alerts at this time</p>
            </div>
          ) : (
            lowStockProducts.slice(0, 5).map((product) => (
              <div 
                key={product.id} 
                className="flex items-center justify-between p-3 bg-destructive/5 rounded-lg border border-destructive/20"
                data-testid={`low-stock-item-${product.id}`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                    <i className="fas fa-cube text-muted-foreground"></i>
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{product.name}</p>
                    <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-destructive font-medium">
                    {product.quantity} {product.unit} left
                  </p>
                  {product.minStock && (
                    <p className="text-xs text-muted-foreground">Min: {product.minStock}</p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
