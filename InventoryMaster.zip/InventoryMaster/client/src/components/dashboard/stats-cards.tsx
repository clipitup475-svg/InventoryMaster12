import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery<{
    totalProducts: number;
    lowStockItems: number;
    totalValue: number;
    todaySales: number;
  }>({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  const cards = [
    {
      title: "Total Products",
      value: stats?.totalProducts || 0,
      icon: "fas fa-box",
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
      trend: "+12% from last month",
      trendColor: "text-green-600",
      testId: "card-total-products",
    },
    {
      title: "Low Stock Items",
      value: stats?.lowStockItems || 0,
      icon: "fas fa-exclamation-triangle",
      iconBg: "bg-destructive/10",
      iconColor: "text-destructive",
      trend: "Needs attention",
      trendColor: "text-destructive",
      testId: "card-low-stock",
    },
    {
      title: "Total Value",
      value: `₹${stats ? Number(stats.totalValue).toLocaleString() : "0"}`,
      icon: "fas fa-rupee-sign",
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: "+8% from last month",
      trendColor: "text-green-600",
      testId: "card-total-value",
    },
    {
      title: "Today's Sales",
      value: `₹${stats ? Number(stats.todaySales).toLocaleString() : "0"}`,
      icon: "fas fa-chart-line",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      trend: "From today's transactions",
      trendColor: "text-blue-600",
      testId: "card-today-sales",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card) => (
        <Card key={card.title} data-testid={card.testId}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <div className="text-3xl font-bold text-foreground">
                  {isLoading ? (
                    <div className="animate-pulse bg-muted h-8 w-20 rounded"></div>
                  ) : (
                    card.value
                  )}
                </div>
              </div>
              <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                <i className={`${card.icon} ${card.iconColor} text-xl`}></i>
              </div>
            </div>
            <div className="mt-4">
              <span className={`text-sm ${card.trendColor}`}>
                {card.title === "Low Stock Items" ? (
                  card.trend
                ) : (
                  <>
                    <i className="fas fa-arrow-up mr-1"></i>
                    {card.trend}
                  </>
                )}
              </span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
