import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import type { ProductWithRelations } from "@shared/schema";

const saleFormSchema = z.object({
  customerName: z.string().optional(),
  customerEmail: z.string().email().optional().or(z.literal("")),
  customerPhone: z.string().optional(),
  paymentMethod: z.enum(["cash", "card", "upi", "bank_transfer"]),
});

type SaleFormData = z.infer<typeof saleFormSchema>;

interface SaleItem {
  productId: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

interface SaleFormProps {
  onSuccess: () => void;
}

export default function SaleForm({ onSuccess }: SaleFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [saleItems, setSaleItems] = useState<SaleItem[]>([]);

  const form = useForm<SaleFormData>({
    resolver: zodResolver(saleFormSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      paymentMethod: "cash",
    },
  });

  // Fetch products for selection
  const { data: products = [] } = useQuery<ProductWithRelations[]>({
    queryKey: ["/api/products"],
    retry: false,
  });

  // Generate invoice number
  const { data: invoiceData } = useQuery<{ invoiceNumber: string }>({
    queryKey: ["/api/sales/generate-invoice-number"],
    retry: false,
  });

  const createSaleMutation = useMutation({
    mutationFn: async (data: { sale: SaleFormData; items: SaleItem[] }) => {
      const taxRate = 0.18; // 18% GST
      const subtotal = data.items.reduce((sum, item) => sum + item.totalPrice, 0);
      const taxAmount = subtotal * taxRate;
      const total = subtotal + taxAmount;

      await apiRequest("POST", "/api/sales", {
        sale: {
          ...data.sale,
          subtotal: subtotal.toString(),
          taxAmount: taxAmount.toString(),
          total: total.toString(),
          status: "completed",
        },
        items: data.items.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.unitPrice.toString(),
          totalPrice: item.totalPrice.toString(),
        })),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Sale completed successfully",
      });
      onSuccess();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to complete sale",
        variant: "destructive",
      });
    },
  });

  const addSaleItem = () => {
    setSaleItems([...saleItems, { productId: "", quantity: 1, unitPrice: 0, totalPrice: 0 }]);
  };

  const removeSaleItem = (index: number) => {
    setSaleItems(saleItems.filter((_, i) => i !== index));
  };

  const updateSaleItem = (index: number, field: keyof SaleItem, value: string | number) => {
    const updatedItems = [...saleItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };

    // Auto-calculate total price when quantity or unit price changes
    if (field === "quantity" || field === "unitPrice") {
      updatedItems[index].totalPrice = updatedItems[index].quantity * updatedItems[index].unitPrice;
    }

    // Auto-fill unit price when product is selected
    if (field === "productId" && value) {
      const product = products.find(p => p.id === value);
      if (product) {
        updatedItems[index].unitPrice = Number(product.sellingPrice);
        updatedItems[index].totalPrice = updatedItems[index].quantity * Number(product.sellingPrice);
      }
    }

    setSaleItems(updatedItems);
  };

  const subtotal = saleItems.reduce((sum, item) => sum + item.totalPrice, 0);
  const taxAmount = subtotal * 0.18; // 18% GST
  const total = subtotal + taxAmount;

  const onSubmit = (data: SaleFormData) => {
    if (saleItems.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one item to the sale",
        variant: "destructive",
      });
      return;
    }

    const invalidItems = saleItems.filter(item => !item.productId || item.quantity <= 0);
    if (invalidItems.length > 0) {
      toast({
        title: "Error",
        description: "Please fill in all item details correctly",
        variant: "destructive",
      });
      return;
    }

    createSaleMutation.mutate({ sale: data, items: saleItems });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Invoice Number */}
        {invoiceData && (
          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm font-medium">Invoice Number: {invoiceData.invoiceNumber}</p>
          </div>
        )}

        {/* Customer Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter customer name" {...field} data-testid="input-customer-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="paymentMethod"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Payment Method</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-payment-method">
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="card">Card</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Sale Items */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <label className="text-sm font-medium text-foreground">Items</label>
            <Button type="button" variant="outline" onClick={addSaleItem} data-testid="button-add-sale-item">
              <i className="fas fa-plus mr-2"></i>
              Add Item
            </Button>
          </div>

          <div className="space-y-3">
            {saleItems.map((item, index) => (
              <Card key={index} className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2">Product</label>
                    <Select
                      value={item.productId}
                      onValueChange={(value) => updateSaleItem(index, "productId", value)}
                    >
                      <SelectTrigger data-testid={`select-sale-product-${index}`}>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        {products
                          .filter(p => p.quantity > 0)
                          .map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.name} - ₹{Number(product.sellingPrice).toLocaleString()} ({product.quantity} available)
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Quantity</label>
                    <Input
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => updateSaleItem(index, "quantity", parseInt(e.target.value) || 0)}
                      data-testid={`input-sale-quantity-${index}`}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Unit Price</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={item.unitPrice}
                      onChange={(e) => updateSaleItem(index, "unitPrice", parseFloat(e.target.value) || 0)}
                      data-testid={`input-sale-unit-price-${index}`}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <label className="block text-sm font-medium mb-2">Total</label>
                      <p className="text-sm font-medium">₹{item.totalPrice.toLocaleString()}</p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSaleItem(index)}
                      data-testid={`button-remove-sale-item-${index}`}
                    >
                      <i className="fas fa-trash text-destructive"></i>
                    </Button>
                  </div>
                </div>
              </Card>
            ))}

            {saleItems.length === 0 && (
              <div className="text-center py-8 border-2 border-dashed border-muted rounded-lg">
                <i className="fas fa-shopping-cart text-4xl text-muted-foreground mb-2"></i>
                <p className="text-muted-foreground">No items added yet</p>
                <p className="text-sm text-muted-foreground">Click "Add Item" to start building the sale</p>
              </div>
            )}
          </div>
        </div>

        {/* Sale Summary */}
        {saleItems.length > 0 && (
          <Card className="bg-muted">
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Subtotal:</span>
                  <span className="text-sm font-medium">₹{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">GST (18%):</span>
                  <span className="text-sm font-medium">₹{taxAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-lg font-semibold border-t pt-2">
                  <span>Total:</span>
                  <span data-testid="text-sale-total">₹{total.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Actions */}
        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" onClick={onSuccess} data-testid="button-cancel-sale">
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={createSaleMutation.isPending || saleItems.length === 0}
            data-testid="button-complete-sale"
          >
            {createSaleMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground mr-2"></div>
                Processing...
              </>
            ) : (
              "Complete Sale"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
