import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import SaleForm from "@/components/sales/sale-form";
import type { SaleWithItems } from "@shared/schema";

export default function Sales() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [showNewSaleDialog, setShowNewSaleDialog] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch recent sales
  const { data: sales = [], isLoading: salesLoading } = useQuery<SaleWithItems[]>({
    queryKey: ["/api/sales"],
    enabled: isAuthenticated,
    retry: false,
  });

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-h-screen">
        <Header 
          title="Sales" 
          subtitle="Record new sales and view transaction history" 
        />
        <main className="flex-1 p-6 bg-muted/30">
          <div className="space-y-6">
            {/* Header Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Sales</h2>
                <p className="text-muted-foreground">Record new sales and view transaction history</p>
              </div>
              <Dialog open={showNewSaleDialog} onOpenChange={setShowNewSaleDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="button-new-sale">
                    <i className="fas fa-plus mr-2"></i>
                    New Sale
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Create New Sale</DialogTitle>
                  </DialogHeader>
                  <SaleForm onSuccess={() => setShowNewSaleDialog(false)} />
                </DialogContent>
              </Dialog>
            </div>

            {/* Quick Sale Section */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Sale Entry</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <i className="fas fa-shopping-cart text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground mb-4">
                    Click "New Sale" to create a quick sale entry
                  </p>
                  <Dialog open={showNewSaleDialog} onOpenChange={setShowNewSaleDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" data-testid="button-quick-sale">
                        <i className="fas fa-plus mr-2"></i>
                        Start Quick Sale
                      </Button>
                    </DialogTrigger>
                  </Dialog>
                </div>
              </CardContent>
            </Card>

            {/* Recent Sales */}
            <Card>
              <CardHeader>
                <CardTitle>
                  Recent Sales
                  {salesLoading && <span className="text-sm font-normal text-muted-foreground ml-2">(Loading...)</span>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {sales.length === 0 && !salesLoading ? (
                    <div className="text-center py-8">
                      <i className="fas fa-receipt text-4xl text-muted-foreground mb-4"></i>
                      <p className="text-muted-foreground">No sales recorded yet</p>
                      <p className="text-sm text-muted-foreground">Create your first sale to see it here</p>
                    </div>
                  ) : (
                    sales.map((sale) => (
                      <div 
                        key={sale.id} 
                        className="flex items-center justify-between p-4 bg-muted rounded-lg"
                        data-testid={`card-sale-${sale.id}`}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <i className="fas fa-receipt text-green-600"></i>
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{sale.invoiceNumber}</p>
                            {sale.customerName && (
                              <p className="text-sm text-muted-foreground">{sale.customerName}</p>
                            )}
                            <p className="text-xs text-muted-foreground">
                              {formatDateTime(sale.createdAt?.toString() || "")} • {sale.items.length} items
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">
                            ₹{Number(sale.total).toLocaleString()}
                          </p>
                          <p className="text-sm text-muted-foreground capitalize">
                            {sale.paymentMethod.replace('_', ' ')}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
