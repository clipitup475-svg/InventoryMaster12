import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Reports() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch dashboard stats for reports
  const { data: stats } = useQuery<{
    totalProducts: number;
    lowStockItems: number;
    totalValue: number;
    todaySales: number;
  }>({
    queryKey: ["/api/dashboard/stats"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Fetch recent sales for top products analysis
  const { data: sales = [] } = useQuery<any[]>({
    queryKey: ["/api/sales"],
    enabled: isAuthenticated,
    retry: false,
  });

  const handleExportCSV = () => {
    toast({
      title: "Export Started",
      description: "CSV export will be available soon",
    });
  };

  const handleExportPDF = () => {
    toast({
      title: "Export Started", 
      description: "PDF export will be available soon",
    });
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-h-screen">
        <Header 
          title="Reports" 
          subtitle="Analytics and insights for your business" 
        />
        <main className="flex-1 p-6 bg-muted/30">
          <div className="space-y-6">
            {/* Header Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Reports</h2>
                <p className="text-muted-foreground">Analytics and insights for your business</p>
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="secondary" 
                  onClick={handleExportCSV}
                  data-testid="button-export-csv"
                >
                  <i className="fas fa-file-csv mr-2"></i>
                  Export CSV
                </Button>
                <Button 
                  onClick={handleExportPDF}
                  data-testid="button-export-pdf"
                >
                  <i className="fas fa-file-pdf mr-2"></i>
                  Export PDF
                </Button>
              </div>
            </div>

            {/* Report Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Report Type</label>
                    <Select defaultValue="sales">
                      <SelectTrigger data-testid="select-report-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sales">Sales Report</SelectItem>
                        <SelectItem value="inventory">Inventory Report</SelectItem>
                        <SelectItem value="profit">Profit Analysis</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Date Range</label>
                    <Select defaultValue="month">
                      <SelectTrigger data-testid="select-date-range">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="week">This Week</SelectItem>
                        <SelectItem value="month">This Month</SelectItem>
                        <SelectItem value="quarter">This Quarter</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Category</label>
                    <Select defaultValue="">
                      <SelectTrigger data-testid="select-category-report">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="electronics">Electronics</SelectItem>
                        <SelectItem value="accessories">Accessories</SelectItem>
                        <SelectItem value="computers">Computers</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Sales Chart Placeholder */}
              <Card>
                <CardHeader>
                  <CardTitle>Sales Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <i className="fas fa-chart-line text-4xl text-muted-foreground mb-2"></i>
                      <p className="text-muted-foreground">Sales trend chart</p>
                      <p className="text-xs text-muted-foreground mt-1">Chart visualization coming soon</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Top Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Sales Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {sales.length === 0 ? (
                      <div className="text-center py-8">
                        <i className="fas fa-chart-bar text-4xl text-muted-foreground mb-2"></i>
                        <p className="text-muted-foreground">No sales data available</p>
                        <p className="text-xs text-muted-foreground">Complete some sales to see insights</p>
                      </div>
                    ) : (
                      sales.slice(0, 5).map((sale, index) => (
                        <div key={sale.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-muted rounded-lg flex items-center justify-center">
                              <span className="text-sm font-medium">{index + 1}</span>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-foreground">{sale.invoiceNumber}</p>
                              <p className="text-xs text-muted-foreground">
                                {sale.customerName || "Walk-in customer"}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-foreground">
                              ₹{Number(sale.total).toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {sale.items.length} items
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Business Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-rupee-sign text-green-600 text-xl"></i>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      ₹{stats ? Number(stats.totalValue).toLocaleString() : "0"}
                    </p>
                    <p className="text-sm text-muted-foreground">Total Inventory Value</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-shopping-cart text-blue-600 text-xl"></i>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      {sales.length}
                    </p>
                    <p className="text-sm text-muted-foreground">Total Sales</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-box text-purple-600 text-xl"></i>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      {stats?.totalProducts || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">Total Products</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-exclamation-triangle text-orange-600 text-xl"></i>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      {stats?.lowStockItems || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">Low Stock Alerts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
