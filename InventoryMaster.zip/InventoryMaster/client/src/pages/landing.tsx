import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Landing() {
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      window.location.href = "/";
    }
  }, [isAuthenticated]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6">
          <div className="text-center space-y-6">
            <div className="space-y-2">
              <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mx-auto">
                <i className="fas fa-boxes text-primary-foreground text-2xl"></i>
              </div>
              <h1 className="text-3xl font-bold text-foreground">StockFlow</h1>
              <p className="text-muted-foreground">
                Professional Inventory Management System
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="text-left space-y-2">
                <h3 className="font-semibold text-foreground">Features:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Real-time inventory tracking</li>
                  <li>• Sales and purchase management</li>
                  <li>• Low stock alerts</li>
                  <li>• Comprehensive reporting</li>
                  <li>• Multi-user support</li>
                </ul>
              </div>
              
              <Button 
                onClick={() => window.location.href = "/api/login"} 
                className="w-full"
                data-testid="button-login"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Sign In to Continue
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
